function [var, mini, maxi] = BenBoundary(BFid)
switch BFid
    %     Unconstrained benchmark functions considered
    case 1 %Sphere
        var=30; mini=-100*ones(1,var); maxi= 100*ones(1,var);
    case 2 %SumSquares
        var=30; mini=-10*ones(1,var); maxi= 10*ones(1,var);
    case 3 %Beale
        var=5; mini=-4.5*ones(1,var); maxi= 4.5*ones(1,var);
    case 4 %Easom
        var=2; mini=100*ones(1,var); maxi=100*ones(1,var);
    case 5 %Matyas
        var=2; mini=-10*ones(1,var); maxi= 10*ones(1,var);
    case 6 %Colville
        var=4; mini=-10*ones(1,var); maxi= 10*ones(1,var);
    case 7 %Trid6
        var=6; mini=-(var^2)*ones(1,var); maxi=(var^2)*ones(1,var);
    case 8 %Trid10
        var=10; mini=-(var^2)*ones(1,var); maxi=(var^2)*ones(1,var);
    case 9 %Zakharov
        var=10; mini=-5*ones(1,var); maxi= 10*ones(1,var);
    case 10 %Schwefel 1.2
        var=30; mini=-100*ones(1,var); maxi=100*ones(1,var);
    case 11 %Rosenbrock
        var=30; mini=-30*ones(1,var); maxi= 30*ones(1,var);
    case 12 %Dixon-Prince
        var=30; mini=-10*ones(1,var); maxi= 10*ones(1,var);
        
    case 13 %Foxholes
        var=2; mini=-65536*ones(1,var); maxi=65536*ones(1,var);
        %     case 14 %Branin
        %         var=2; mini=[-5,10]*ones(1,var); maxi=[0,15]*ones(1,var);
    case 15 %Bohachevsky 1
        var=2; mini=-100*ones(1,var); maxi= 100*ones(1,var);
    case 16 %Booth
        var=2; mini=-10*ones(1,var); maxi= 10*ones(1,var);
    case 17 %Michalewicz 2
        var=2; mini=0*ones(1,var); maxi=pi*ones(1,var);
    case 18 %Michalewicz 5
        var=5; mini=0*ones(1,var); maxi=pi*ones(1,var);
    case 19 %Bohachevsky 2
        var=2; mini=-100*ones(1,var); maxi= 100*ones(1,var);
    case 20 %Bohachevsky 3
        var=2; mini=-100*ones(1,var); maxi= 100*ones(1,var);
    case 21 %GoldStein_Prince
        var=2; mini=-2*ones(1,var); maxi=2*ones(1,var);
    case 22 %Perm
        var=4; mini=-var*ones(1,var); maxi=var*ones(1,var);
    case 23 %Hartman 3
        var=3; mini=0*ones(1,var); maxi= 1*ones(1,var);
    case 24 %Ackley
        var=30; mini=-32*ones(1,var); maxi=32*ones(1,var);
    case 25 %Penalized 2
        var=30; mini=-50*ones(1,var); maxi= 50*ones(1,var);
    case 26 %Langerman 2
        var=2; mini=0*ones(1,var); maxi= 10*ones(1,var);
    case 27 %Langerman 5
        var=5; mini=0*ones(1,var); maxi= 10*ones(1,var);
    case 28 %Langerman 10
        var=10; mini=0*ones(1,var); maxi= 10*ones(1,var);
    case 29 %FlotcherPowell 5
        var=5; mini=-pi*ones(1,var); maxi=pi*ones(1,var);
    case 30 %FlotcherPowell 1
        var=10; mini=-pi*ones(1,var); maxi=pi*ones(1,var);
end
end